var min = 0;
var sec = 0;
var miliSec = 0;
var interval;

var min_para = document.getElementById("min");
var sec_para = document.getElementById("sec");
var miliSec_para = document.getElementById("miliSec");

function timeout(){
    miliSec++;
    miliSec_para.innerHTML = miliSec;
    
    if(miliSec >= 100){
        sec++;
        sec_para.innerHTML = sec;
        miliSec = 0;
    }
    else if(sec >= 60){
        min++;
        min_para.innerHTML = min;
        sec = 0;
    }
}


function startBtn(){
   var start = document.getElementById("startButton");
   interval = setInterval( timeout , 10);
   start.disabled = true;
}

function pauseBtn(){
    clearInterval(interval);
    var start = document.getElementById("startButton");
    start.disabled = false;
    
}

function resetBtn(){
    clearInterval(interval);
    min = 0;
    sec = 0;
    miliSec = 0;

    min_para.innerHTML = 0;
    sec_para.innerHTML = 0;
    miliSec_para.innerHTML = 0;
    var start = document.getElementById("startButton");
    start.disabled = false;
    
}


// function reset(){
//     clearInterval(interval)
//     msecPara.innerHTML = 0
//     secPara.innerHTML = 0
//     minPara.innerHTML = 0
//     min=0
//     sec=0
//     msec=0

// }





// var minPara = document.getElementById("min")
// var secPara = document.getElementById("sec")
// var msecPara = document.getElementById("msec")
// var min = 0
// var sec = 0
// var msec = 0
// var interval;
// function timer(){
//     msec++  
//     msecPara.innerHTML = msec
//     if(msec == 100){
//         sec++
//         secPara.innerHTML = sec
//         msec = 0
//     }else if(sec == 60){
//         min++
//         minPara.innerHTML = min
//         sec = 0
//     }
    

// }



// function start(){
//     var startBtn =document.getElementById("startBtn")
//     interval = setInterval( timer , 10 );
//     startBtn.disabled = true

// }

// function stop(){
//     var startBtn =document.getElementById("startBtn")

//     clearInterval(interval)
//     startBtn.disabled = false

// }


// function reset(){
//     clearInterval(interval)
//     msecPara.innerHTML = 0
//     secPara.innerHTML = 0
//     minPara.innerHTML = 0
//     min=0
//     sec=0
//     msec=0

// }








// var min = 0;
// var sec = 0;
// var miliSec = 0;
// var interval;

// var m = document.getElementById("min");
// var s = document.getElementById("sec");
// var ms = document.getElementById("miliSec");

// function timeOut(){
//     miliSec++;
//     m.innerHTML = miliSec;
//     if(miliSec >= 100){
//         sec++;
//         s.innerHTML = sec;
//         miliSec = 0;
//     }
//     else if(sec >= 60){
//         min++;
//         m.innerHTML = min;
//         sec = 0;
//     }
// }

// function start(){
//     interval = setInterval(timeOut , 10);
//     interval;
//     var startBtn = document.getElementById("strtBtn");
//     startBtn.disabled = true;
// }

// function pause(){
//     clearInterval(interval);
//     var startBtn = document.getElementById("strtBtn");
//     startBtn.disabled = false;
// }

// function reset(){
//     clearInterval(interval);
//     min = 0;
//     sec = 0;
//     miliSec = 0;
//     m.innerHTML = 0;
//     s.innerHTML = 0;
//     ms.innerHTML = 0;

// }





